<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Karima</title>
    <link rel="stylesheet" type="text/css" href="/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/app.css')); ?>">
    <link href='http://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
    <link href="css/flexslider.css" rel="stylesheet" >
    <link href="css/styles.css" rel="stylesheet">
    <link href="css/queries.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
      </head>
      <body id="top">
        <header id="home">
          <nav>
            <div class="container-fluid">
              <div class="row">
                <div class="col-md-8 col-md-offset-2 col-sm-8 col-sm-offset-2 col-xs-8 col-xs-offset-2">
                  <nav class="pull">
                    <ul class="top-nav">
                      <li><a href="#intro">Profile <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
                      <li><a href="#skill">Skill <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
                      <li><a href="#info">Info lebih <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
                      <li><a href="#contact">Kontak saya <span class="indicator"><i class="fa fa-angle-right"></i></span></a></li>
                    </ul>
                  </nav>
                </div>
              </div>
            </div>
          </nav>
          <section class="hero" id="hero">
            <div class="container">
              <div class="row">
                <div class="col-md-12 text-right navicon">
                  <a id="nav-toggle" class="nav_slide_button" href="#"><span></span></a>
                </div>
              </div>
              <div class="row">
                <div class="col-md-8 col-md-offset-2 text-center inner">
                  <h1 class="animated fadeInDown">KARIMA   <span>SITI MASNA</span></h1>
                  <!--<p class="animated fadeInUp delay-05s">An exclusive HTML5/CSS3 freebie by Peter Finlan, for <em>Codrops</em></p> -->
                </div>
              </div>
              <div class="row">
                <div class="col-md-6 col-md-offset-3 text-center">
                  <a href="http://tympanus.net/codrops/?p=19439" class="learn-more-btn">Unduh CV saya disini</a>
                </div>
              </div>
            </div>
          </section>
        </header>
        <section class="intro text-center section-padding" id="intro">
          <div class="container">
            <div class="row">
              <div class="col-md-8 col-md-offset-2 wp1">
                <h1 class="arrow">Profile</h1>
                <p>Halo, perkenalkan nama saya <a href="#">Karima Siti Masna</a>. Saya berumur 22 tahun dan memiliki ketertarikan pada bidang IT. Saya sedang mempelajari framework Laravel dan ingin mempelajari hal baru lainnya. Saya menyukai bermain game dan menonton anime di waktu senggang saya. </p>
              </div>
            </div>
          </div>
        </section>
        <section class="features text-center section-padding" id="skill">
          <div class="container">
            <div class="row">
              <div class="col-md-12">
                <h1 class="arrow">Skill</h1>
                <div class="features-wrapper">
                  <div class="col-md-4 wp2">
                    <div class="icon">
                      <i class="fa fa-laptop shadow"></i>
                    </div>
                    <h2>Developing Game</h2>
                    <p>Menyukai membuat game menggunakan game engine Unity 3D. Salah satu game yang pernah dibuat yaitu "Flow" yang dikerjakan sebagai skripsi S1 di UNINDRA Jakarta.</p>
                  </div>
                  <div class="col-md-4 wp2 delay-05s">
                    <div class="icon">
                      <i class="fa fa-code shadow"></i>
                    </div>
                    <h2>Laravel</h2>
                    <p>Untuk backend developement saya sedang mempelajari Laravel framework dan akan belajaran tentang yang lainnya juga</p>
                  </div>
                  <div class="col-md-4 wp2 delay-1s">
                    <div class="icon">
                      <i class="fa fa-heart shadow"></i>
                    </div>
                    <h2>Git</h2>
                    <p>nanti mau belajar kan? ehe.</p>
                  </div>
                  <div class="clearfix"></div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <section class="portfolio text-center section-padding" id="info">
              <div class="container">
                <div class="row">
                  <div id="portfolioSlider">
                  </div>
                </div>
              </div>
              <h1 class="arrow">Pengalaman Bekerja</h1>
              <p>PT. Arista Latindo  </p>
              <p>Export Administrator </p>
              <p> 2018 - 2019 </p>
              <br>
              </div>

              <div>
              <h1 class="arrow">Sertifikasi</h1>
              <p>Computer Technical - 2019 </p>
              <p> <a href="#">Pusat Pelatihan Kerja Daerah Jakarta Selatan </a> </p>
              <p> </p>
              <p>Computer Technical - 2019</p>
              <p> <a href="#">Kompetensi BNSP</a> </p>
              <br>
             </div>

             <div>
               <h1 class="arrow">Edukasi</h1>
               <p> <a href="#">Universitas Indraprasta PGRI</a> </p>
               <p>Teknik Informatika </p>
               <p> </p>
               <a href="#">SMK Negeri 28 Jakarta - 2016</a></p>
               <p>Akomodasi Perhotelan</p>
               <p> <a href="#">SMP Negeri 86 Jakarta - 2013</a> </p>
               <br>
              </div>
            </section>

            <section class="dark-bg text-center section-padding contact-wrap" id="contact">
              <a href="#top" class="up-btn"><i class="fa fa-chevron-up"></i></a>
              <div class="container">
                <div class="row">
                  <div class="col-md-12">
                    <h1 class="arrow">Hubungi melalui</h1>
                  </div>
                </div>
                <div class="row contact-details">
                  <div class="col-md-4">
                    <div class="light-box box-hover">
                      <h2><i class="fa fa-map-marker"></i><span>Alamat</span></h2>
                      <p>Jl. Pelita dalam no.19, Cilandak Barat</p>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="light-box box-hover">
                      <h2><i class="fa fa-mobile"></i><span>Phone / Whatsapp / Telegram</span></h2>
                      <p>0856-9437-0329</p>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="light-box box-hover">
                      <h2><i class="fa fa-paper-plane"></i><span>Email</span></h2>
                      <p><a href="#">karimamanil71@gmail.com</a></p>
                    </div>
                  </div>
                </div>
            </section>
            <footer>
              <div class="container">
                <div class="row">
                  <div class="col-md-6">
                    <ul class="legals">
                      <li><a href="#">Terms &amp; Conditions</a></li>
                      <li><a href="#">Legals</a></li>
                    </ul>
                  </div>
                  <div class="col-md-6 credit">
                    <p>Designed &amp; Developed by <a href="http://www.peterfinlan.com/">Peter Finlan</a> exclusively for <a href="http://tympanus.net/codrops/"><em>Codrops</em></a></p>
                  </div>
                </div>
              </div>
            </footer>
            <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
            <!-- Include all compiled plugins (below), or include individual files as needed -->
            <script src="js/waypoints.min.js"></script>
            <script src="js/bootstrap.min.js"></script>
            <script src="js/scripts.js"></script>
            <script src="js/jquery.flexslider.js"></script>
            <script src="js/modernizr.js"></script>
          </body>
        </html>
<?php /**PATH /home/karima/profil/resources/views/welcome.blade.php ENDPATH**/ ?>